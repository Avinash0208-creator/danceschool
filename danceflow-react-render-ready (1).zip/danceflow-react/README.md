# DanceFlow Pro — React + Express

This project converts the supplied `DS FINAL - Copy.html` into a React frontend
served together with an Express backend.

## Run locally

```bash
npm install
npm run dev
```

Frontend: http://localhost:5173

Backend health check: http://localhost:10000/api/health

## Production build

```bash
npm install
npm run build
npm start
```

## Render deployment

This repository is configured for Render with `render.yaml`.

- Build command: `npm install && npm run build`
- Start command: `npm start`

The visual HTML/CSS and the existing interaction logic are preserved to keep
the deployed output the same as the supplied HTML.

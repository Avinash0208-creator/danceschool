import { useEffect, useRef } from "react";
import { bodyTemplate } from "./bodyTemplate";
import legacyCode from "./legacy.js?raw";
import "./styles.css";

/*
  The original HTML markup and CSS are retained verbatim inside a React
  component so the rendered UI remains visually identical to the supplied
  DanceFlow HTML. The original interaction code is mounted after React
  renders the DOM, preserving the existing buttons, navigation, modals,
  login flow, dark mode, tables, etc.
*/

export default function App() {
  const hostRef = useRef(null);

  useEffect(() => {
    const script = document.createElement("script");
    script.text = legacyCode;
    document.body.appendChild(script);

    return () => {
      script.remove();
    };
  }, []);

  return (
    <div
      ref={hostRef}
      dangerouslySetInnerHTML={{ __html: bodyTemplate }}
    />
  );
}



/* ==========================================================
   LOGIN
========================================================== */

document
.getElementById("loginForm")
.addEventListener(
"submit",
function(event){

event.preventDefault();

let email =
document.getElementById("loginEmail").value;

let password =
document.getElementById("loginPassword").value;


/* Demo authentication */

if(
email === "admin@gmail.com"
&&
password === "123456"
){

startApp(
"Dance Admin",
email
);

}else if(email && password){

startApp(
email.split("@")[0],
email
);

}else{

showToast(
"Please enter valid login details"
);

}

});


/* ==========================================================
   GOOGLE LOGIN
========================================================== */

function googleLogin(){

/*

Frontend demo.

Real Google OAuth requires
Google Identity Services and a
Google OAuth Client ID.

*/

let account =
prompt(
"Google Account\n\nEnter the Google account email:"
);

if(!account){

return;

}

if(!account.includes("@")){

showToast(
"Please enter a valid Google account"
);

return;

}

startApp(
account.split("@")[0],
account
);

showToast(
"Google account selected"
);

}


/* ==========================================================
   START APPLICATION
========================================================== */

function startApp(name,email){

document
.getElementById("loginScreen")
.style.display="none";

document
.getElementById("forgotScreen")
.style.display="none";

document
.getElementById("app")
.style.display="block";


name =
name.charAt(0).toUpperCase()
+
name.slice(1);


document
.getElementById("topName")
.textContent=name;


document
.getElementById("topAvatar")
.textContent=
name.charAt(0).toUpperCase();


document
.getElementById("profileName")
.value=name;


document
.getElementById("profileEmail")
.value=email;


document
.getElementById("profileAvatar")
.textContent=
name.charAt(0).toUpperCase();


showPage("dashboard");

}


/* ==========================================================
   NAVIGATION
========================================================== */

function showPage(page,button){

document
.querySelectorAll(".page")
.forEach(
function(item){

item.classList.remove("active");

});


let target =
document.getElementById(page);

if(target){

target.classList.add("active");

}


document
.querySelectorAll(".nav button")
.forEach(
function(btn){

btn.classList.remove("active");

});


if(button){

button.classList.add("active");

}


let pageInfo={

dashboard:
[
"Dashboard",
"Welcome back to DanceFlow"
],

students:
[
"Students",
"Manage student registrations"
],

teachers:
[
"Teachers",
"Manage professional instructors"
],

classes:
[
"Dance Classes",
"Manage dance programs"
],

attendance:
[
"Attendance",
"Track student attendance"
],

payments:
[
"Payments",
"Manage school fees"
],

timetable:
[
"Timetable",
"Weekly dance schedule"
],

reports:
[
"Analytics & Reports",
"School performance overview"
],

announcements:
[
"Announcements",
"School news and updates"
],

profile:
[
"My Profile",
"Manage your account"
],

settings:
[
"Settings",
"Customize your system"
]

};


document
.getElementById("pageTitle")
.textContent=
pageInfo[page][0];


document
.getElementById("pageSubtitle")
.textContent=
pageInfo[page][1];


document
.getElementById("sidebar")
.classList.remove("open");


window.scrollTo({
top:0,
behavior:"smooth"
});

}


/* ==========================================================
   SIDEBAR
========================================================== */

function toggleSidebar(){

document
.getElementById("sidebar")
.classList.toggle("open");

}


/* ==========================================================
   STUDENT MODAL
========================================================== */

function openStudentModal(){

document
.getElementById("studentModal")
.classList.add("show");

}


function closeStudentModal(){

document
.getElementById("studentModal")
.classList.remove("show");

}


/* ==========================================================
   ADD STUDENT
========================================================== */

function addStudent(){

let name =
document.getElementById("newName").value.trim();

let email =
document.getElementById("newEmail").value.trim();

let dance =
document.getElementById("newDance").value;

let age =
document.getElementById("newAge").value;


if(
!name ||
!email ||
!age
){

showToast(
"Please fill all student details"
);

return;

}


let table =
document.getElementById("studentBody");

let id =
"ST" +
String(
table.rows.length+1
).padStart(3,"0");


let row =
table.insertRow();


row.innerHTML=`

<td>
${id}
</td>

<td>
<strong>
${name}
</strong>
</td>

<td>
${email}
</td>

<td>
${dance}
</td>

<td>
${age}
</td>

<td>

<span class="badge badge-green">
Active
</span>

</td>

<td>

<button
class="action-btn edit"
onclick="editStudent(this)">

✏️

</button>

<button
class="action-btn delete"
onclick="deleteStudent(this)">

🗑️

</button>

</td>

`;


closeStudentModal();


document.getElementById("newName").value="";
document.getElementById("newEmail").value="";
document.getElementById("newAge").value="";


updateStudentCount();


showToast(
"Student added successfully!"
);

}


/* ==========================================================
   DELETE STUDENT
========================================================== */

function deleteStudent(button){

if(
confirm(
"Are you sure you want to delete this student?"
)
){

button
.closest("tr")
.remove();

updateStudentCount();

showToast(
"Student deleted successfully"
);

}

}


/* ==========================================================
   EDIT STUDENT
========================================================== */

function editStudent(button){

let row =
button.closest("tr");

let oldName =
row.cells[1].innerText;

let newName =
prompt(
"Enter new student name:",
oldName
);

if(
newName &&
newName.trim()
){

row.cells[1].innerHTML=
`<strong>${newName}</strong>`;

showToast(
"Student updated successfully"
);

}

}


/* ==========================================================
   SEARCH STUDENTS
========================================================== */

function searchStudents(){

let search =
document
.getElementById("studentSearch")
.value
.toLowerCase();

let rows =
document
.getElementById("studentBody")
.getElementsByTagName("tr");


for(
let i=0;
i<rows.length;
i++
){

let text =
rows[i]
.innerText
.toLowerCase();

rows[i].style.display=
text.includes(search)
?
""
:
"none";

}

}


/* ==========================================================
   UPDATE STUDENT COUNT
========================================================== */

function updateStudentCount(){

let rows =
document
.getElementById("studentBody")
.getElementsByTagName("tr");

let count=128;

count +=
rows.length-4;

document
.getElementById("studentCount")
.textContent=
count;

}


/* ==========================================================
   ATTENDANCE
========================================================== */

function markAttendance(){

let selects =
document.querySelectorAll(
".attendance-select"
);

let present=0;

selects.forEach(
function(select){

if(
select.value==="Present"
){

present++;

}

});


showToast(
"Attendance saved successfully! " +
present +
" students marked present."
);

}


/* ==========================================================
   PAYMENT
========================================================== */

function addPayment(){

showToast(
"Payment recorded successfully!"
);

}


/* ==========================================================
   PROFILE
========================================================== */

function saveProfile(){

let name =
document
.getElementById("profileName")
.value
.trim();

let email =
document
.getElementById("profileEmail")
.value
.trim();


if(!name || !email){

showToast(
"Please enter your profile details"
);

return;

}


document
.getElementById("topName")
.textContent=name;


document
.getElementById("topAvatar")
.textContent=
name.charAt(0).toUpperCase();


document
.getElementById("profileAvatar")
.textContent=
name.charAt(0).toUpperCase();


showToast(
"Profile updated successfully!"
);

}


/* ==========================================================
   DARK MODE
========================================================== */

function toggleDarkMode(){

document
.body
.classList.toggle("dark");


if(
document
.body
.classList
.contains("dark")
){

localStorage.setItem(
"danceflowDark",
"true"
);

}else{

localStorage.setItem(
"danceflowDark",
"false"
);

}

}


if(
localStorage.getItem(
"danceflowDark"
)
==="true"
){

document
.body
.classList.add("dark");

}


/* ==========================================================
   FORGOT PASSWORD
========================================================== */

let generatedOTP="";


function openForgot(){

document
.getElementById("loginScreen")
.style.display="none";

document
.getElementById("forgotScreen")
.style.display="flex";

}


function backLogin(){

document
.getElementById("forgotScreen")
.style.display="none";

document
.getElementById("loginScreen")
.style.display="flex";

}


/* ==========================================================
   SEND OTP
========================================================== */

function sendOTP(){

let email =
document
.getElementById("resetEmail")
.value
.trim();


if(!email){

showToast(
"Enter your Gmail address"
);

return;

}


generatedOTP =
Math.floor(
100000 +
Math.random()*900000
).toString();


/*

DEMO ONLY.

A real application should send this OTP
from a secure backend to Gmail.

*/

alert(
"DEMO OTP: " +
generatedOTP +
"\n\nFor a real application, connect this form to a backend email service."
);


document
.getElementById("emailStep")
.style.display="none";


document
.getElementById("otpStep")
.style.display="block";

}


/* ==========================================================
   VERIFY OTP
========================================================== */

function verifyOTP(){

let entered =
document
.getElementById("otpInput")
.value;


if(
entered===generatedOTP
){

showToast(
"OTP verified successfully!"
);


document
.getElementById("otpStep")
.style.display="none";


document
.getElementById("passwordStep")
.style.display="block";

}else{

showToast(
"Invalid OTP"
);

}

}


/* ==========================================================
   CHANGE PASSWORD
========================================================== */

function changePassword(){

let password =
document
.getElementById("newPassword")
.value;

let confirm =
document
.getElementById("confirmPassword")
.value;


if(password.length<6){

showToast(
"Password must contain at least 6 characters"
);

return;

}


if(password!==confirm){

showToast(
"Passwords do not match"
);

return;

}


showToast(
"Password changed successfully!"
);


setTimeout(
function(){

backLogin();

},
1500
);

}


/* ==========================================================
   LOGOUT
========================================================== */

function logout(){

if(
confirm(
"Are you sure you want to logout?"
)
){

document
.getElementById("app")
.style.display="none";


document
.getElementById("loginScreen")
.style.display="flex";


document
.getElementById("loginEmail")
.value="";


document
.getElementById("loginPassword")
.value="";


showToast(
"Logged out successfully"
);

}

}


/* ==========================================================
   TOAST
========================================================== */

function showToast(message){

let toast =
document
.getElementById("toast");


toast.textContent=
message;


toast.classList.add("show");


clearTimeout(
window.toastTimer
);


window.toastTimer=
setTimeout(
function(){

toast.classList.remove("show");

},
3000
);

}


/* ==========================================================
   CLOSE MODAL ON OUTSIDE CLICK
========================================================== */

document
.getElementById("studentModal")
.addEventListener(
"click",
function(event){

if(
event.target===this
){

closeStudentModal();

}

});

